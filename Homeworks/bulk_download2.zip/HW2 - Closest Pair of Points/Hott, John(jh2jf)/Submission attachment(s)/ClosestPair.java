/**
 * CS4102 Fall 2019 -- Homework 2
 *********************************
 * Collaboration Policy: You are encouraged to collaborate with up to 4 other
 * students, but all work submitted must be your own independently written
 * solution. List the computing ids of all of your collaborators in the comment
 * at the top of your java or python file. Do not seek published or online
 * solutions for any assignments. If you use any published or online resources
 * (which may not include solutions) when completing this assignment, be sure to
 * cite them. Do not submit a solution that you are unable to explain orally to a
 * member of the course staff.
 *********************************
 * Your Computing ID: jh2jf 
 * Collaborators: njb2b, dw4u
 * Sources: Introduction to Algorithms, Cormen
 **************************************/
import java.util.List;

public class ClosestPair {

    /**
     * This is the method that should set off the computation
     * of closest pair.  It takes as input a list lines of input
     * as strings.  You should parse that input and then call a
     * subroutine that you write to compute the closest pair distance
     * and return that value from this method
     *
     * @return the distance between the closest pair 
     */
    public double compute(List<String> fileData) {
        return 0.0;
    }
}
